/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/search";
exports.ids = ["pages/search"];
exports.modules = {

/***/ "(pages-dir-node)/./components/Layout.js":
/*!******************************!*\
  !*** ./components/Layout.js ***!
  \******************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Layout)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _MainNav__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./MainNav */ \"(pages-dir-node)/./components/MainNav.js\");\n/* harmony import */ var _barrel_optimize_names_Container_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! __barrel_optimize__?names=Container!=!react-bootstrap */ \"(pages-dir-node)/__barrel_optimize__?names=Container!=!./node_modules/react-bootstrap/esm/index.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_MainNav__WEBPACK_IMPORTED_MODULE_1__]);\n_MainNav__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n/*********************************************************************************\r\n* WEB422 – Assignment 4\r\n*\r\n* I declare that this assignment is my own work in accordance with Seneca's\r\n* Academic Integrity Policy:\r\n*\r\n* https://www.senecapolytechnic.ca/about/policies/academic-integrity-policy.html\r\n*\r\n* Name: Khiet Van Phan Student ID:147072235  Date: July 4th, 2025\r\n*\r\n********************************************************************************/ \n\n\nfunction Layout({ children }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_MainNav__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {}, void 0, false, {\n                fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\components\\\\Layout.js\",\n                lineNumber: 19,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\components\\\\Layout.js\",\n                lineNumber: 20,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Container_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Container, {\n                className: \"mt-5\",\n                children: children\n            }, void 0, false, {\n                fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\components\\\\Layout.js\",\n                lineNumber: 21,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\components\\\\Layout.js\",\n                lineNumber: 24,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHBhZ2VzLWRpci1ub2RlKS8uL2NvbXBvbmVudHMvTGF5b3V0LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQUE7Ozs7Ozs7Ozs7K0VBVStFLEdBQUc7QUFFbEQ7QUFDWTtBQUU3QixTQUFTRSxPQUFPLEVBQUVDLFFBQVEsRUFBRTtJQUN6QyxxQkFDRTs7MEJBQ0UsOERBQUNILGdEQUFPQTs7Ozs7MEJBQ1IsOERBQUNJOzs7OzswQkFDRCw4REFBQ0gsdUZBQVNBO2dCQUFDSSxXQUFVOzBCQUNsQkY7Ozs7OzswQkFFSCw4REFBQ0M7Ozs7Ozs7QUFHUCIsInNvdXJjZXMiOlsiRDpcXEpPQU5ORVxcU0VORUNBXFxTVTI1XFxXRUI0MjJcXEE1XFxteS1hcHBcXGNvbXBvbmVudHNcXExheW91dC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXHJcbiogV0VCNDIyIOKAkyBBc3NpZ25tZW50IDRcclxuKlxyXG4qIEkgZGVjbGFyZSB0aGF0IHRoaXMgYXNzaWdubWVudCBpcyBteSBvd24gd29yayBpbiBhY2NvcmRhbmNlIHdpdGggU2VuZWNhJ3NcclxuKiBBY2FkZW1pYyBJbnRlZ3JpdHkgUG9saWN5OlxyXG4qXHJcbiogaHR0cHM6Ly93d3cuc2VuZWNhcG9seXRlY2huaWMuY2EvYWJvdXQvcG9saWNpZXMvYWNhZGVtaWMtaW50ZWdyaXR5LXBvbGljeS5odG1sXHJcbipcclxuKiBOYW1lOiBLaGlldCBWYW4gUGhhbiBTdHVkZW50IElEOjE0NzA3MjIzNSAgRGF0ZTogSnVseSA0dGgsIDIwMjVcclxuKlxyXG4qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi8gXHJcblxyXG5pbXBvcnQgTWFpbk5hdiBmcm9tICcuL01haW5OYXYnO1xyXG5pbXBvcnQgeyBDb250YWluZXIgfSBmcm9tICdyZWFjdC1ib290c3RyYXAnO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTGF5b3V0KHsgY2hpbGRyZW4gfSkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8TWFpbk5hdiAvPlxyXG4gICAgICA8YnIgLz5cclxuICAgICAgPENvbnRhaW5lciBjbGFzc05hbWU9XCJtdC01XCI+XHJcbiAgICAgICAge2NoaWxkcmVufVxyXG4gICAgICA8L0NvbnRhaW5lcj5cclxuICAgICAgPGJyLz5cclxuICAgIDwvPlxyXG4gICk7XHJcbn0iXSwibmFtZXMiOlsiTWFpbk5hdiIsIkNvbnRhaW5lciIsIkxheW91dCIsImNoaWxkcmVuIiwiYnIiLCJjbGFzc05hbWUiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(pages-dir-node)/./components/Layout.js\n");

/***/ }),

/***/ "(pages-dir-node)/./components/MainNav.js":
/*!*******************************!*\
  !*** ./components/MainNav.js ***!
  \*******************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ MainNav)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"(pages-dir-node)/./node_modules/next/router.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! __barrel_optimize__?names=Button,Container,Form,Nav,NavDropdown,Navbar!=!react-bootstrap */ \"(pages-dir-node)/__barrel_optimize__?names=Button,Container,Form,Nav,NavDropdown,Navbar!=!./node_modules/react-bootstrap/esm/index.js\");\n/* harmony import */ var jotai__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! jotai */ \"jotai\");\n/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/store */ \"(pages-dir-node)/./store.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/link */ \"(pages-dir-node)/./node_modules/next/link.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([jotai__WEBPACK_IMPORTED_MODULE_3__, _store__WEBPACK_IMPORTED_MODULE_4__]);\n([jotai__WEBPACK_IMPORTED_MODULE_3__, _store__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n\n\n\nfunction MainNav() {\n    const [searchField, setSearchField] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');\n    const [isExpanded, setIsExpanded] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);\n    const [isClient, setIsClient] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();\n    if (!router.isReady) return null; // Ensure router is ready before using it\n    const [searchHistory, setSearchHistory] = (0,jotai__WEBPACK_IMPORTED_MODULE_3__.useAtom)(_store__WEBPACK_IMPORTED_MODULE_4__.searchHistoryAtom);\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)({\n        \"MainNav.useEffect\": ()=>{\n            setIsClient(true);\n        }\n    }[\"MainNav.useEffect\"], []);\n    function submitHandler(e) {\n        e.preventDefault();\n        if (searchField.trim()) {\n            const queryString = `title=true&q=${searchField}`;\n            router.push(`/artwork?${queryString}`);\n            setSearchHistory((current)=>[\n                    ...current,\n                    queryString\n                ]);\n            setSearchField('');\n            setIsExpanded(false);\n        }\n    }\n    if (!isClient || !router.isReady) return null;\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_6__.Navbar, {\n        expand: \"lg\",\n        className: \"fixed-top navbar-dark bg-dark\",\n        expanded: isExpanded,\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_6__.Container, {\n            children: [\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_6__.Navbar.Brand, {\n                    children: \"Khiet Van Phan\"\n                }, void 0, false, {\n                    fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\components\\\\MainNav.js\",\n                    lineNumber: 37,\n                    columnNumber: 9\n                }, this),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_6__.Navbar.Toggle, {\n                    \"aria-controls\": \"main-navbar-nav\",\n                    onClick: ()=>setIsExpanded(!isExpanded)\n                }, void 0, false, {\n                    fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\components\\\\MainNav.js\",\n                    lineNumber: 38,\n                    columnNumber: 9\n                }, this),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_6__.Navbar.Collapse, {\n                    id: \"main-navbar-nav\",\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_6__.Nav, {\n                            className: \"me-auto\",\n                            children: [\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {\n                                    href: \"/\",\n                                    passHref: true,\n                                    legacyBehavior: true,\n                                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_6__.Nav.Link, {\n                                        active: router.pathname === '/',\n                                        onClick: ()=>setIsExpanded(false),\n                                        as: \"span\",\n                                        children: \"Home\"\n                                    }, void 0, false, {\n                                        fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\components\\\\MainNav.js\",\n                                        lineNumber: 42,\n                                        columnNumber: 15\n                                    }, this)\n                                }, void 0, false, {\n                                    fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\components\\\\MainNav.js\",\n                                    lineNumber: 41,\n                                    columnNumber: 13\n                                }, this),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {\n                                    href: \"/search\",\n                                    passHref: true,\n                                    legacyBehavior: true,\n                                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_6__.Nav.Link, {\n                                        active: router.isReady && router.pathname === '/search',\n                                        onClick: ()=>setIsExpanded(false),\n                                        as: \"span\",\n                                        children: \"Advanced Search\"\n                                    }, void 0, false, {\n                                        fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\components\\\\MainNav.js\",\n                                        lineNumber: 51,\n                                        columnNumber: 15\n                                    }, this)\n                                }, void 0, false, {\n                                    fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\components\\\\MainNav.js\",\n                                    lineNumber: 50,\n                                    columnNumber: 13\n                                }, this)\n                            ]\n                        }, void 0, true, {\n                            fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\components\\\\MainNav.js\",\n                            lineNumber: 40,\n                            columnNumber: 11\n                        }, this),\n                        \"\\xa0\",\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_6__.Form, {\n                            className: \"d-flex\",\n                            onSubmit: submitHandler,\n                            children: [\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_6__.Form.Control, {\n                                    type: \"search\",\n                                    placeholder: \"Search\",\n                                    className: \"me-2\",\n                                    value: searchField,\n                                    onChange: (e)=>setSearchField(e.target.value)\n                                }, void 0, false, {\n                                    fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\components\\\\MainNav.js\",\n                                    lineNumber: 62,\n                                    columnNumber: 13\n                                }, this),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_6__.Button, {\n                                    type: \"submit\",\n                                    variant: \"outline-light\",\n                                    children: \"Search\"\n                                }, void 0, false, {\n                                    fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\components\\\\MainNav.js\",\n                                    lineNumber: 69,\n                                    columnNumber: 13\n                                }, this)\n                            ]\n                        }, void 0, true, {\n                            fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\components\\\\MainNav.js\",\n                            lineNumber: 61,\n                            columnNumber: 11\n                        }, this),\n                        \"\\xa0\",\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_6__.Nav, {\n                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_6__.NavDropdown, {\n                                title: \"User Name\",\n                                id: \"basic-nav-dropdown\",\n                                children: [\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_6__.NavDropdown.Item, {\n                                        as: (next_link__WEBPACK_IMPORTED_MODULE_5___default()),\n                                        href: \"/favourites\",\n                                        active: router.isReady && router.pathname === '/favourites',\n                                        onClick: ()=>setIsExpanded(false),\n                                        children: \"Favourites\"\n                                    }, void 0, false, {\n                                        fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\components\\\\MainNav.js\",\n                                        lineNumber: 76,\n                                        columnNumber: 15\n                                    }, this),\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_6__.NavDropdown.Item, {\n                                        as: (next_link__WEBPACK_IMPORTED_MODULE_5___default()),\n                                        href: \"/history\",\n                                        active: router.isReady && router.pathname === '/history',\n                                        onClick: ()=>setIsExpanded(false),\n                                        children: \"Search History\"\n                                    }, void 0, false, {\n                                        fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\components\\\\MainNav.js\",\n                                        lineNumber: 85,\n                                        columnNumber: 15\n                                    }, this)\n                                ]\n                            }, void 0, true, {\n                                fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\components\\\\MainNav.js\",\n                                lineNumber: 75,\n                                columnNumber: 13\n                            }, this)\n                        }, void 0, false, {\n                            fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\components\\\\MainNav.js\",\n                            lineNumber: 74,\n                            columnNumber: 11\n                        }, this)\n                    ]\n                }, void 0, true, {\n                    fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\components\\\\MainNav.js\",\n                    lineNumber: 39,\n                    columnNumber: 9\n                }, this)\n            ]\n        }, void 0, true, {\n            fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\components\\\\MainNav.js\",\n            lineNumber: 36,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\components\\\\MainNav.js\",\n        lineNumber: 35,\n        columnNumber: 5\n    }, this);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHBhZ2VzLWRpci1ub2RlKS8uL2NvbXBvbmVudHMvTWFpbk5hdi5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQTRDO0FBQ0o7QUFDNEM7QUFDcEQ7QUFDWTtBQUNmO0FBRWQsU0FBU1k7SUFDdEIsTUFBTSxDQUFDQyxhQUFhQyxlQUFlLEdBQUdkLCtDQUFRQSxDQUFDO0lBQy9DLE1BQU0sQ0FBQ2UsWUFBWUMsY0FBYyxHQUFHaEIsK0NBQVFBLENBQUM7SUFDN0MsTUFBTSxDQUFDaUIsVUFBVUMsWUFBWSxHQUFHbEIsK0NBQVFBLENBQUM7SUFDekMsTUFBTW1CLFNBQVNqQixzREFBU0E7SUFDeEIsSUFBRyxDQUFDaUIsT0FBT0MsT0FBTyxFQUFFLE9BQU8sTUFBTSx5Q0FBeUM7SUFDMUUsTUFBTSxDQUFDQyxlQUFlQyxpQkFBaUIsR0FBR2IsOENBQU9BLENBQUNDLHFEQUFpQkE7SUFHbkVULGdEQUFTQTs2QkFBQztZQUNSaUIsWUFBWTtRQUNkOzRCQUFHLEVBQUU7SUFFTCxTQUFTSyxjQUFjQyxDQUFDO1FBQ3RCQSxFQUFFQyxjQUFjO1FBQ2hCLElBQUlaLFlBQVlhLElBQUksSUFBSTtZQUN0QixNQUFNQyxjQUFjLENBQUMsYUFBYSxFQUFFZCxhQUFhO1lBQ2pETSxPQUFPUyxJQUFJLENBQUMsQ0FBQyxTQUFTLEVBQUVELGFBQWE7WUFDckNMLGlCQUFpQk8sQ0FBQUEsVUFBVzt1QkFBSUE7b0JBQVNGO2lCQUFZO1lBQ3JEYixlQUFlO1lBQ2ZFLGNBQWM7UUFDaEI7SUFDRjtJQUVBLElBQUksQ0FBQ0MsWUFBWSxDQUFDRSxPQUFPQyxPQUFPLEVBQUUsT0FBTztJQUV6QyxxQkFDRSw4REFBQ2pCLHVIQUFNQTtRQUFDMkIsUUFBTztRQUFLQyxXQUFVO1FBQWdDQyxVQUFVakI7a0JBQ3RFLDRFQUFDViwwSEFBU0E7OzhCQUNSLDhEQUFDRix1SEFBTUEsQ0FBQzhCLEtBQUs7OEJBQUM7Ozs7Ozs4QkFDZCw4REFBQzlCLHVIQUFNQSxDQUFDK0IsTUFBTTtvQkFBQ0MsaUJBQWM7b0JBQWtCQyxTQUFTLElBQU1wQixjQUFjLENBQUNEOzs7Ozs7OEJBQzdFLDhEQUFDWix1SEFBTUEsQ0FBQ2tDLFFBQVE7b0JBQUNDLElBQUc7O3NDQUNsQiw4REFBQ2xDLG9IQUFHQTs0QkFBQzJCLFdBQVU7OzhDQUNiLDhEQUFDcEIsa0RBQUlBO29DQUFDNEIsTUFBSztvQ0FBSUMsUUFBUTtvQ0FBQ0MsY0FBYzs4Q0FDcEMsNEVBQUNyQyxvSEFBR0EsQ0FBQ08sSUFBSTt3Q0FDUCtCLFFBQVF2QixPQUFPd0IsUUFBUSxLQUFLO3dDQUM1QlAsU0FBUyxJQUFNcEIsY0FBYzt3Q0FDN0I0QixJQUFHO2tEQUNKOzs7Ozs7Ozs7Ozs4Q0FJSCw4REFBQ2pDLGtEQUFJQTtvQ0FBQzRCLE1BQUs7b0NBQVVDLFFBQVE7b0NBQUNDLGNBQWM7OENBQzFDLDRFQUFDckMsb0hBQUdBLENBQUNPLElBQUk7d0NBQ1ArQixRQUFRdkIsT0FBT0MsT0FBTyxJQUFJRCxPQUFPd0IsUUFBUSxLQUFLO3dDQUM5Q1AsU0FBUyxJQUFNcEIsY0FBYzt3Q0FDN0I0QixJQUFHO2tEQUNKOzs7Ozs7Ozs7Ozs7Ozs7Ozt3QkFJQztzQ0FFTiw4REFBQ3RDLHFIQUFJQTs0QkFBQ3lCLFdBQVU7NEJBQVNjLFVBQVV0Qjs7OENBQ2pDLDhEQUFDakIscUhBQUlBLENBQUN3QyxPQUFPO29DQUNYQyxNQUFLO29DQUNMQyxhQUFZO29DQUNaakIsV0FBVTtvQ0FDVmtCLE9BQU9wQztvQ0FDUHFDLFVBQVUsQ0FBQzFCLElBQU1WLGVBQWVVLEVBQUUyQixNQUFNLENBQUNGLEtBQUs7Ozs7Ozs4Q0FFaEQsOERBQUMxQyx1SEFBTUE7b0NBQUN3QyxNQUFLO29DQUFTSyxTQUFROzhDQUFnQjs7Ozs7Ozs7Ozs7O3dCQUd6QztzQ0FFUCw4REFBQ2hELG9IQUFHQTtzQ0FDRiw0RUFBQ0ksNEhBQVdBO2dDQUFDNkMsT0FBTTtnQ0FBWWYsSUFBRzs7a0RBQ2hDLDhEQUFDOUIsNEhBQVdBLENBQUM4QyxJQUFJO3dDQUNmVixJQUFJakMsa0RBQUlBO3dDQUNSNEIsTUFBSzt3Q0FDTEcsUUFBUXZCLE9BQU9DLE9BQU8sSUFBSUQsT0FBT3dCLFFBQVEsS0FBSzt3Q0FDOUNQLFNBQVMsSUFBTXBCLGNBQWM7a0RBQzlCOzs7Ozs7a0RBSUQsOERBQUNSLDRIQUFXQSxDQUFDOEMsSUFBSTt3Q0FDZlYsSUFBSWpDLGtEQUFJQTt3Q0FDUjRCLE1BQUs7d0NBQ0xHLFFBQVF2QixPQUFPQyxPQUFPLElBQUlELE9BQU93QixRQUFRLEtBQUs7d0NBQzlDUCxTQUFTLElBQU1wQixjQUFjO2tEQUM5Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQVNmIiwic291cmNlcyI6WyJEOlxcSk9BTk5FXFxTRU5FQ0FcXFNVMjVcXFdFQjQyMlxcQTVcXG15LWFwcFxcY29tcG9uZW50c1xcTWFpbk5hdi5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tICduZXh0L3JvdXRlcic7XHJcbmltcG9ydCB7IE5hdmJhciwgTmF2LCBDb250YWluZXIsIEZvcm0sIEJ1dHRvbiwgTmF2RHJvcGRvd24gfSBmcm9tICdyZWFjdC1ib290c3RyYXAnO1xyXG5pbXBvcnQgeyB1c2VBdG9tIH0gZnJvbSAnam90YWknO1xyXG5pbXBvcnQgeyBzZWFyY2hIaXN0b3J5QXRvbSB9IGZyb20gJ0Avc3RvcmUnO1xyXG5pbXBvcnQgTGluayBmcm9tICduZXh0L2xpbmsnO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTWFpbk5hdigpIHtcclxuICBjb25zdCBbc2VhcmNoRmllbGQsIHNldFNlYXJjaEZpZWxkXSA9IHVzZVN0YXRlKCcnKTtcclxuICBjb25zdCBbaXNFeHBhbmRlZCwgc2V0SXNFeHBhbmRlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2lzQ2xpZW50LCBzZXRJc0NsaWVudF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcbiAgaWYoIXJvdXRlci5pc1JlYWR5KSByZXR1cm4gbnVsbDsgLy8gRW5zdXJlIHJvdXRlciBpcyByZWFkeSBiZWZvcmUgdXNpbmcgaXRcclxuICBjb25zdCBbc2VhcmNoSGlzdG9yeSwgc2V0U2VhcmNoSGlzdG9yeV0gPSB1c2VBdG9tKHNlYXJjaEhpc3RvcnlBdG9tKTtcclxuXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBzZXRJc0NsaWVudCh0cnVlKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIGZ1bmN0aW9uIHN1Ym1pdEhhbmRsZXIoZSkge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgaWYgKHNlYXJjaEZpZWxkLnRyaW0oKSkge1xyXG4gICAgICBjb25zdCBxdWVyeVN0cmluZyA9IGB0aXRsZT10cnVlJnE9JHtzZWFyY2hGaWVsZH1gO1xyXG4gICAgICByb3V0ZXIucHVzaChgL2FydHdvcms/JHtxdWVyeVN0cmluZ31gKTtcclxuICAgICAgc2V0U2VhcmNoSGlzdG9yeShjdXJyZW50ID0+IFsuLi5jdXJyZW50LCBxdWVyeVN0cmluZ10pO1xyXG4gICAgICBzZXRTZWFyY2hGaWVsZCgnJyk7XHJcbiAgICAgIHNldElzRXhwYW5kZWQoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgaWYgKCFpc0NsaWVudCB8fCAhcm91dGVyLmlzUmVhZHkpIHJldHVybiBudWxsO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPE5hdmJhciBleHBhbmQ9XCJsZ1wiIGNsYXNzTmFtZT1cImZpeGVkLXRvcCBuYXZiYXItZGFyayBiZy1kYXJrXCIgZXhwYW5kZWQ9e2lzRXhwYW5kZWR9PlxyXG4gICAgICA8Q29udGFpbmVyPlxyXG4gICAgICAgIDxOYXZiYXIuQnJhbmQ+S2hpZXQgVmFuIFBoYW48L05hdmJhci5CcmFuZD5cclxuICAgICAgICA8TmF2YmFyLlRvZ2dsZSBhcmlhLWNvbnRyb2xzPVwibWFpbi1uYXZiYXItbmF2XCIgb25DbGljaz17KCkgPT4gc2V0SXNFeHBhbmRlZCghaXNFeHBhbmRlZCl9IC8+XHJcbiAgICAgICAgPE5hdmJhci5Db2xsYXBzZSBpZD1cIm1haW4tbmF2YmFyLW5hdlwiPlxyXG4gICAgICAgICAgPE5hdiBjbGFzc05hbWU9XCJtZS1hdXRvXCI+XHJcbiAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvXCIgcGFzc0hyZWYgbGVnYWN5QmVoYXZpb3I+XHJcbiAgICAgICAgICAgICAgPE5hdi5MaW5rXHJcbiAgICAgICAgICAgICAgICBhY3RpdmU9e3JvdXRlci5wYXRobmFtZSA9PT0gJy8nfVxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNFeHBhbmRlZChmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICBhcz1cInNwYW5cIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIEhvbWVcclxuICAgICAgICAgICAgICA8L05hdi5MaW5rPlxyXG4gICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvc2VhcmNoXCIgcGFzc0hyZWYgbGVnYWN5QmVoYXZpb3I+XHJcbiAgICAgICAgICAgICAgPE5hdi5MaW5rXHJcbiAgICAgICAgICAgICAgICBhY3RpdmU9e3JvdXRlci5pc1JlYWR5ICYmIHJvdXRlci5wYXRobmFtZSA9PT0gJy9zZWFyY2gnfVxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNFeHBhbmRlZChmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICBhcz1cInNwYW5cIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIEFkdmFuY2VkIFNlYXJjaFxyXG4gICAgICAgICAgICAgIDwvTmF2Lkxpbms+XHJcbiAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgIDwvTmF2PlxyXG4gICAgICAgICAgJm5ic3A7XHJcbiAgICAgICAgICA8Rm9ybSBjbGFzc05hbWU9XCJkLWZsZXhcIiBvblN1Ym1pdD17c3VibWl0SGFuZGxlcn0+XHJcbiAgICAgICAgICAgIDxGb3JtLkNvbnRyb2xcclxuICAgICAgICAgICAgICB0eXBlPVwic2VhcmNoXCJcclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaFwiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWUtMlwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e3NlYXJjaEZpZWxkfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VhcmNoRmllbGQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJzdWJtaXRcIiB2YXJpYW50PVwib3V0bGluZS1saWdodFwiPlxyXG4gICAgICAgICAgICAgIFNlYXJjaFxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDwvRm9ybT5cclxuICAgICAgICAgICZuYnNwO1xyXG4gICAgICAgICAgPE5hdj5cclxuICAgICAgICAgICAgPE5hdkRyb3Bkb3duIHRpdGxlPVwiVXNlciBOYW1lXCIgaWQ9XCJiYXNpYy1uYXYtZHJvcGRvd25cIj5cclxuICAgICAgICAgICAgICA8TmF2RHJvcGRvd24uSXRlbVxyXG4gICAgICAgICAgICAgICAgYXM9e0xpbmt9XHJcbiAgICAgICAgICAgICAgICBocmVmPVwiL2Zhdm91cml0ZXNcIlxyXG4gICAgICAgICAgICAgICAgYWN0aXZlPXtyb3V0ZXIuaXNSZWFkeSAmJiByb3V0ZXIucGF0aG5hbWUgPT09ICcvZmF2b3VyaXRlcyd9XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc0V4cGFuZGVkKGZhbHNlKX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBGYXZvdXJpdGVzXHJcbiAgICAgICAgICAgICAgPC9OYXZEcm9wZG93bi5JdGVtPlxyXG5cclxuICAgICAgICAgICAgICA8TmF2RHJvcGRvd24uSXRlbVxyXG4gICAgICAgICAgICAgICAgYXM9e0xpbmt9XHJcbiAgICAgICAgICAgICAgICBocmVmPVwiL2hpc3RvcnlcIlxyXG4gICAgICAgICAgICAgICAgYWN0aXZlPXtyb3V0ZXIuaXNSZWFkeSAmJiByb3V0ZXIucGF0aG5hbWUgPT09ICcvaGlzdG9yeSd9XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc0V4cGFuZGVkKGZhbHNlKX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBTZWFyY2ggSGlzdG9yeVxyXG4gICAgICAgICAgICAgIDwvTmF2RHJvcGRvd24uSXRlbT5cclxuICAgICAgICAgICAgPC9OYXZEcm9wZG93bj5cclxuICAgICAgICAgIDwvTmF2PlxyXG4gICAgICAgIDwvTmF2YmFyLkNvbGxhcHNlPlxyXG4gICAgICA8L0NvbnRhaW5lcj5cclxuICAgIDwvTmF2YmFyPlxyXG4gICk7XHJcbn1cclxuIl0sIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlUm91dGVyIiwiTmF2YmFyIiwiTmF2IiwiQ29udGFpbmVyIiwiRm9ybSIsIkJ1dHRvbiIsIk5hdkRyb3Bkb3duIiwidXNlQXRvbSIsInNlYXJjaEhpc3RvcnlBdG9tIiwiTGluayIsIk1haW5OYXYiLCJzZWFyY2hGaWVsZCIsInNldFNlYXJjaEZpZWxkIiwiaXNFeHBhbmRlZCIsInNldElzRXhwYW5kZWQiLCJpc0NsaWVudCIsInNldElzQ2xpZW50Iiwicm91dGVyIiwiaXNSZWFkeSIsInNlYXJjaEhpc3RvcnkiLCJzZXRTZWFyY2hIaXN0b3J5Iiwic3VibWl0SGFuZGxlciIsImUiLCJwcmV2ZW50RGVmYXVsdCIsInRyaW0iLCJxdWVyeVN0cmluZyIsInB1c2giLCJjdXJyZW50IiwiZXhwYW5kIiwiY2xhc3NOYW1lIiwiZXhwYW5kZWQiLCJCcmFuZCIsIlRvZ2dsZSIsImFyaWEtY29udHJvbHMiLCJvbkNsaWNrIiwiQ29sbGFwc2UiLCJpZCIsImhyZWYiLCJwYXNzSHJlZiIsImxlZ2FjeUJlaGF2aW9yIiwiYWN0aXZlIiwicGF0aG5hbWUiLCJhcyIsIm9uU3VibWl0IiwiQ29udHJvbCIsInR5cGUiLCJwbGFjZWhvbGRlciIsInZhbHVlIiwib25DaGFuZ2UiLCJ0YXJnZXQiLCJ2YXJpYW50IiwidGl0bGUiLCJJdGVtIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(pages-dir-node)/./components/MainNav.js\n");

/***/ }),

/***/ "(pages-dir-node)/./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2Fsearch&preferredRegion=&absolutePagePath=.%2Fpages%5Csearch.js&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D!":
/*!************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2Fsearch&preferredRegion=&absolutePagePath=.%2Fpages%5Csearch.js&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D! ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   config: () => (/* binding */ config),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   getServerSideProps: () => (/* binding */ getServerSideProps),\n/* harmony export */   getStaticPaths: () => (/* binding */ getStaticPaths),\n/* harmony export */   getStaticProps: () => (/* binding */ getStaticProps),\n/* harmony export */   reportWebVitals: () => (/* binding */ reportWebVitals),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   unstable_getServerProps: () => (/* binding */ unstable_getServerProps),\n/* harmony export */   unstable_getServerSideProps: () => (/* binding */ unstable_getServerSideProps),\n/* harmony export */   unstable_getStaticParams: () => (/* binding */ unstable_getStaticParams),\n/* harmony export */   unstable_getStaticPaths: () => (/* binding */ unstable_getStaticPaths),\n/* harmony export */   unstable_getStaticProps: () => (/* binding */ unstable_getStaticProps)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/route-modules/pages/module.compiled */ \"(pages-dir-node)/./node_modules/next/dist/server/route-modules/pages/module.compiled.js\");\n/* harmony import */ var next_dist_server_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/route-kind */ \"(pages-dir-node)/./node_modules/next/dist/server/route-kind.js\");\n/* harmony import */ var next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/build/templates/helpers */ \"(pages-dir-node)/./node_modules/next/dist/build/templates/helpers.js\");\n/* harmony import */ var private_next_pages_document__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! private-next-pages/_document */ \"(pages-dir-node)/./pages/_document.js\");\n/* harmony import */ var private_next_pages_app__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! private-next-pages/_app */ \"(pages-dir-node)/./pages/_app.js\");\n/* harmony import */ var _pages_search_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pages\\search.js */ \"(pages-dir-node)/./pages/search.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_app__WEBPACK_IMPORTED_MODULE_4__, _pages_search_js__WEBPACK_IMPORTED_MODULE_5__]);\n([private_next_pages_app__WEBPACK_IMPORTED_MODULE_4__, _pages_search_js__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n// Import the app and document modules.\n\n\n// Import the userland code.\n\n// Re-export the component (should be the default export).\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_search_js__WEBPACK_IMPORTED_MODULE_5__, 'default'));\n// Re-export methods.\nconst getStaticProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_search_js__WEBPACK_IMPORTED_MODULE_5__, 'getStaticProps');\nconst getStaticPaths = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_search_js__WEBPACK_IMPORTED_MODULE_5__, 'getStaticPaths');\nconst getServerSideProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_search_js__WEBPACK_IMPORTED_MODULE_5__, 'getServerSideProps');\nconst config = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_search_js__WEBPACK_IMPORTED_MODULE_5__, 'config');\nconst reportWebVitals = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_search_js__WEBPACK_IMPORTED_MODULE_5__, 'reportWebVitals');\n// Re-export legacy methods.\nconst unstable_getStaticProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_search_js__WEBPACK_IMPORTED_MODULE_5__, 'unstable_getStaticProps');\nconst unstable_getStaticPaths = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_search_js__WEBPACK_IMPORTED_MODULE_5__, 'unstable_getStaticPaths');\nconst unstable_getStaticParams = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_search_js__WEBPACK_IMPORTED_MODULE_5__, 'unstable_getStaticParams');\nconst unstable_getServerProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_search_js__WEBPACK_IMPORTED_MODULE_5__, 'unstable_getServerProps');\nconst unstable_getServerSideProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_search_js__WEBPACK_IMPORTED_MODULE_5__, 'unstable_getServerSideProps');\n// Create and export the route module that will be consumed.\nconst routeModule = new next_dist_server_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0__.PagesRouteModule({\n    definition: {\n        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.PAGES,\n        page: \"/search\",\n        pathname: \"/search\",\n        // The following aren't used in production.\n        bundlePath: '',\n        filename: ''\n    },\n    components: {\n        // default export might not exist when optimized for data only\n        App: private_next_pages_app__WEBPACK_IMPORTED_MODULE_4__[\"default\"],\n        Document: private_next_pages_document__WEBPACK_IMPORTED_MODULE_3__[\"default\"]\n    },\n    userland: _pages_search_js__WEBPACK_IMPORTED_MODULE_5__\n});\n\n//# sourceMappingURL=pages.js.map\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHBhZ2VzLWRpci1ub2RlKS8uL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvYnVpbGQvd2VicGFjay9sb2FkZXJzL25leHQtcm91dGUtbG9hZGVyL2luZGV4LmpzP2tpbmQ9UEFHRVMmcGFnZT0lMkZzZWFyY2gmcHJlZmVycmVkUmVnaW9uPSZhYnNvbHV0ZVBhZ2VQYXRoPS4lMkZwYWdlcyU1Q3NlYXJjaC5qcyZhYnNvbHV0ZUFwcFBhdGg9cHJpdmF0ZS1uZXh0LXBhZ2VzJTJGX2FwcCZhYnNvbHV0ZURvY3VtZW50UGF0aD1wcml2YXRlLW5leHQtcGFnZXMlMkZfZG9jdW1lbnQmbWlkZGxld2FyZUNvbmZpZ0Jhc2U2ND1lMzAlM0QhIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBd0Y7QUFDaEM7QUFDRTtBQUMxRDtBQUN5RDtBQUNWO0FBQy9DO0FBQytDO0FBQy9DO0FBQ0EsaUVBQWUsd0VBQUssQ0FBQyw2Q0FBUSxZQUFZLEVBQUM7QUFDMUM7QUFDTyx1QkFBdUIsd0VBQUssQ0FBQyw2Q0FBUTtBQUNyQyx1QkFBdUIsd0VBQUssQ0FBQyw2Q0FBUTtBQUNyQywyQkFBMkIsd0VBQUssQ0FBQyw2Q0FBUTtBQUN6QyxlQUFlLHdFQUFLLENBQUMsNkNBQVE7QUFDN0Isd0JBQXdCLHdFQUFLLENBQUMsNkNBQVE7QUFDN0M7QUFDTyxnQ0FBZ0Msd0VBQUssQ0FBQyw2Q0FBUTtBQUM5QyxnQ0FBZ0Msd0VBQUssQ0FBQyw2Q0FBUTtBQUM5QyxpQ0FBaUMsd0VBQUssQ0FBQyw2Q0FBUTtBQUMvQyxnQ0FBZ0Msd0VBQUssQ0FBQyw2Q0FBUTtBQUM5QyxvQ0FBb0Msd0VBQUssQ0FBQyw2Q0FBUTtBQUN6RDtBQUNPLHdCQUF3QixrR0FBZ0I7QUFDL0M7QUFDQSxjQUFjLGtFQUFTO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLGFBQWEsOERBQVc7QUFDeEIsa0JBQWtCLG1FQUFnQjtBQUNsQyxLQUFLO0FBQ0wsWUFBWTtBQUNaLENBQUM7O0FBRUQsaUMiLCJzb3VyY2VzIjpbIiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQYWdlc1JvdXRlTW9kdWxlIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvcm91dGUtbW9kdWxlcy9wYWdlcy9tb2R1bGUuY29tcGlsZWRcIjtcbmltcG9ydCB7IFJvdXRlS2luZCB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL3JvdXRlLWtpbmRcIjtcbmltcG9ydCB7IGhvaXN0IH0gZnJvbSBcIm5leHQvZGlzdC9idWlsZC90ZW1wbGF0ZXMvaGVscGVyc1wiO1xuLy8gSW1wb3J0IHRoZSBhcHAgYW5kIGRvY3VtZW50IG1vZHVsZXMuXG5pbXBvcnQgKiBhcyBkb2N1bWVudCBmcm9tIFwicHJpdmF0ZS1uZXh0LXBhZ2VzL19kb2N1bWVudFwiO1xuaW1wb3J0ICogYXMgYXBwIGZyb20gXCJwcml2YXRlLW5leHQtcGFnZXMvX2FwcFwiO1xuLy8gSW1wb3J0IHRoZSB1c2VybGFuZCBjb2RlLlxuaW1wb3J0ICogYXMgdXNlcmxhbmQgZnJvbSBcIi4vcGFnZXNcXFxcc2VhcmNoLmpzXCI7XG4vLyBSZS1leHBvcnQgdGhlIGNvbXBvbmVudCAoc2hvdWxkIGJlIHRoZSBkZWZhdWx0IGV4cG9ydCkuXG5leHBvcnQgZGVmYXVsdCBob2lzdCh1c2VybGFuZCwgJ2RlZmF1bHQnKTtcbi8vIFJlLWV4cG9ydCBtZXRob2RzLlxuZXhwb3J0IGNvbnN0IGdldFN0YXRpY1Byb3BzID0gaG9pc3QodXNlcmxhbmQsICdnZXRTdGF0aWNQcm9wcycpO1xuZXhwb3J0IGNvbnN0IGdldFN0YXRpY1BhdGhzID0gaG9pc3QodXNlcmxhbmQsICdnZXRTdGF0aWNQYXRocycpO1xuZXhwb3J0IGNvbnN0IGdldFNlcnZlclNpZGVQcm9wcyA9IGhvaXN0KHVzZXJsYW5kLCAnZ2V0U2VydmVyU2lkZVByb3BzJyk7XG5leHBvcnQgY29uc3QgY29uZmlnID0gaG9pc3QodXNlcmxhbmQsICdjb25maWcnKTtcbmV4cG9ydCBjb25zdCByZXBvcnRXZWJWaXRhbHMgPSBob2lzdCh1c2VybGFuZCwgJ3JlcG9ydFdlYlZpdGFscycpO1xuLy8gUmUtZXhwb3J0IGxlZ2FjeSBtZXRob2RzLlxuZXhwb3J0IGNvbnN0IHVuc3RhYmxlX2dldFN0YXRpY1Byb3BzID0gaG9pc3QodXNlcmxhbmQsICd1bnN0YWJsZV9nZXRTdGF0aWNQcm9wcycpO1xuZXhwb3J0IGNvbnN0IHVuc3RhYmxlX2dldFN0YXRpY1BhdGhzID0gaG9pc3QodXNlcmxhbmQsICd1bnN0YWJsZV9nZXRTdGF0aWNQYXRocycpO1xuZXhwb3J0IGNvbnN0IHVuc3RhYmxlX2dldFN0YXRpY1BhcmFtcyA9IGhvaXN0KHVzZXJsYW5kLCAndW5zdGFibGVfZ2V0U3RhdGljUGFyYW1zJyk7XG5leHBvcnQgY29uc3QgdW5zdGFibGVfZ2V0U2VydmVyUHJvcHMgPSBob2lzdCh1c2VybGFuZCwgJ3Vuc3RhYmxlX2dldFNlcnZlclByb3BzJyk7XG5leHBvcnQgY29uc3QgdW5zdGFibGVfZ2V0U2VydmVyU2lkZVByb3BzID0gaG9pc3QodXNlcmxhbmQsICd1bnN0YWJsZV9nZXRTZXJ2ZXJTaWRlUHJvcHMnKTtcbi8vIENyZWF0ZSBhbmQgZXhwb3J0IHRoZSByb3V0ZSBtb2R1bGUgdGhhdCB3aWxsIGJlIGNvbnN1bWVkLlxuZXhwb3J0IGNvbnN0IHJvdXRlTW9kdWxlID0gbmV3IFBhZ2VzUm91dGVNb2R1bGUoe1xuICAgIGRlZmluaXRpb246IHtcbiAgICAgICAga2luZDogUm91dGVLaW5kLlBBR0VTLFxuICAgICAgICBwYWdlOiBcIi9zZWFyY2hcIixcbiAgICAgICAgcGF0aG5hbWU6IFwiL3NlYXJjaFwiLFxuICAgICAgICAvLyBUaGUgZm9sbG93aW5nIGFyZW4ndCB1c2VkIGluIHByb2R1Y3Rpb24uXG4gICAgICAgIGJ1bmRsZVBhdGg6ICcnLFxuICAgICAgICBmaWxlbmFtZTogJydcbiAgICB9LFxuICAgIGNvbXBvbmVudHM6IHtcbiAgICAgICAgLy8gZGVmYXVsdCBleHBvcnQgbWlnaHQgbm90IGV4aXN0IHdoZW4gb3B0aW1pemVkIGZvciBkYXRhIG9ubHlcbiAgICAgICAgQXBwOiBhcHAuZGVmYXVsdCxcbiAgICAgICAgRG9jdW1lbnQ6IGRvY3VtZW50LmRlZmF1bHRcbiAgICB9LFxuICAgIHVzZXJsYW5kXG59KTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cGFnZXMuanMubWFwIl0sIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(pages-dir-node)/./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2Fsearch&preferredRegion=&absolutePagePath=.%2Fpages%5Csearch.js&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D!\n");

/***/ }),

/***/ "(pages-dir-node)/./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var bootstrap_dist_css_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bootstrap/dist/css/bootstrap.min.css */ \"(pages-dir-node)/./node_modules/bootstrap/dist/css/bootstrap.min.css\");\n/* harmony import */ var bootstrap_dist_css_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bootstrap_dist_css_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/styles/globals.css */ \"(pages-dir-node)/./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/components/Layout */ \"(pages-dir-node)/./components/Layout.js\");\n/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! swr */ \"swr\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Layout__WEBPACK_IMPORTED_MODULE_3__, swr__WEBPACK_IMPORTED_MODULE_4__]);\n([_components_Layout__WEBPACK_IMPORTED_MODULE_3__, swr__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n\nconst fetcher = async (url)=>{\n    const response = await fetch(url);\n    if (!response.ok) {\n        const error = new Error('An error occurred while fetching the data.');\n        // Attach extra info to the error object.\n        error.info = await res.json();\n        error.status = res.status;\n        throw error;\n    }\n    return response.json();\n};\nfunction App({ Component, pageProps }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_Layout__WEBPACK_IMPORTED_MODULE_3__[\"default\"], {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(swr__WEBPACK_IMPORTED_MODULE_4__.SWRConfig, {\n            value: {\n                fetcher\n            },\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                ...pageProps\n            }, void 0, false, {\n                fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\_app.js\",\n                lineNumber: 21,\n                columnNumber: 9\n            }, this)\n        }, void 0, false, {\n            fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\_app.js\",\n            lineNumber: 20,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\_app.js\",\n        lineNumber: 19,\n        columnNumber: 5\n    }, this);\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (App);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHBhZ2VzLWRpci1ub2RlKS8uL3BhZ2VzL19hcHAuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUE4QztBQUNoQjtBQUNXO0FBQ1Q7QUFFaEMsTUFBTUUsVUFBVSxPQUFPQztJQUNyQixNQUFNQyxXQUFXLE1BQU1DLE1BQU1GO0lBQzNCLElBQUksQ0FBQ0MsU0FBU0UsRUFBRSxFQUFFO1FBQ2hCLE1BQU1DLFFBQVEsSUFBSUMsTUFBTTtRQUN4Qix5Q0FBeUM7UUFDekNELE1BQU1FLElBQUksR0FBRyxNQUFNQyxJQUFJQyxJQUFJO1FBQzNCSixNQUFNSyxNQUFNLEdBQUdGLElBQUlFLE1BQU07UUFDekIsTUFBTUw7SUFDUjtJQUNGLE9BQU9ILFNBQVNPLElBQUk7QUFDdEI7QUFDQSxTQUFTRSxJQUFJLEVBQUVDLFNBQVMsRUFBRUMsU0FBUyxFQUFFO0lBQ25DLHFCQUNFLDhEQUFDZiwwREFBTUE7a0JBQ0wsNEVBQUNDLDBDQUFTQTtZQUFDZSxPQUFPO2dCQUFFZDtZQUFRO3NCQUMxQiw0RUFBQ1k7Z0JBQVcsR0FBR0MsU0FBUzs7Ozs7Ozs7Ozs7Ozs7OztBQUloQztBQUVBLGlFQUFlRixHQUFHQSxFQUFDIiwic291cmNlcyI6WyJEOlxcSk9BTk5FXFxTRU5FQ0FcXFNVMjVcXFdFQjQyMlxcQTVcXG15LWFwcFxccGFnZXNcXF9hcHAuanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICdib290c3RyYXAvZGlzdC9jc3MvYm9vdHN0cmFwLm1pbi5jc3MnO1xuaW1wb3J0ICdAL3N0eWxlcy9nbG9iYWxzLmNzcyc7XG5pbXBvcnQgTGF5b3V0IGZyb20gJ0AvY29tcG9uZW50cy9MYXlvdXQnO1xuaW1wb3J0IHsgU1dSQ29uZmlnIH0gZnJvbSAnc3dyJztcblxuY29uc3QgZmV0Y2hlciA9IGFzeW5jICh1cmwpID0+IHtcbiAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaCh1cmwpO1xuICAgIGlmICghcmVzcG9uc2Uub2spIHtcbiAgICAgIGNvbnN0IGVycm9yID0gbmV3IEVycm9yKCdBbiBlcnJvciBvY2N1cnJlZCB3aGlsZSBmZXRjaGluZyB0aGUgZGF0YS4nKVxuICAgICAgLy8gQXR0YWNoIGV4dHJhIGluZm8gdG8gdGhlIGVycm9yIG9iamVjdC5cbiAgICAgIGVycm9yLmluZm8gPSBhd2FpdCByZXMuanNvbigpXG4gICAgICBlcnJvci5zdGF0dXMgPSByZXMuc3RhdHVzXG4gICAgICB0aHJvdyBlcnJvcjtcbiAgICB9XG4gIHJldHVybiByZXNwb25zZS5qc29uKCk7XG59XG5mdW5jdGlvbiBBcHAoeyBDb21wb25lbnQsIHBhZ2VQcm9wcyB9KSB7XG4gIHJldHVybiAoXG4gICAgPExheW91dD5cbiAgICAgIDxTV1JDb25maWcgdmFsdWU9e3sgZmV0Y2hlciB9fT5cbiAgICAgICAgPENvbXBvbmVudCB7Li4ucGFnZVByb3BzfSAvPlxuICAgICAgPC9TV1JDb25maWc+XG4gICAgPC9MYXlvdXQ+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcDtcbiJdLCJuYW1lcyI6WyJMYXlvdXQiLCJTV1JDb25maWciLCJmZXRjaGVyIiwidXJsIiwicmVzcG9uc2UiLCJmZXRjaCIsIm9rIiwiZXJyb3IiLCJFcnJvciIsImluZm8iLCJyZXMiLCJqc29uIiwic3RhdHVzIiwiQXBwIiwiQ29tcG9uZW50IiwicGFnZVByb3BzIiwidmFsdWUiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(pages-dir-node)/./pages/_app.js\n");

/***/ }),

/***/ "(pages-dir-node)/./pages/_document.js":
/*!****************************!*\
  !*** ./pages/_document.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Document)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/document */ \"(pages-dir-node)/./node_modules/next/document.js\");\n/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_document__WEBPACK_IMPORTED_MODULE_1__);\n\n\nfunction Document() {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.Html, {\n        lang: \"en\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.Head, {}, void 0, false, {\n                fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\_document.js\",\n                lineNumber: 6,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"body\", {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.Main, {}, void 0, false, {\n                        fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\_document.js\",\n                        lineNumber: 8,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.NextScript, {}, void 0, false, {\n                        fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\_document.js\",\n                        lineNumber: 9,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\_document.js\",\n                lineNumber: 7,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\_document.js\",\n        lineNumber: 5,\n        columnNumber: 5\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHBhZ2VzLWRpci1ub2RlKS8uL3BhZ2VzL19kb2N1bWVudC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBNkQ7QUFFOUMsU0FBU0k7SUFDdEIscUJBQ0UsOERBQUNKLCtDQUFJQTtRQUFDSyxNQUFLOzswQkFDVCw4REFBQ0osK0NBQUlBOzs7OzswQkFDTCw4REFBQ0s7O2tDQUNDLDhEQUFDSiwrQ0FBSUE7Ozs7O2tDQUNMLDhEQUFDQyxxREFBVUE7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBSW5CIiwic291cmNlcyI6WyJEOlxcSk9BTk5FXFxTRU5FQ0FcXFNVMjVcXFdFQjQyMlxcQTVcXG15LWFwcFxccGFnZXNcXF9kb2N1bWVudC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBIdG1sLCBIZWFkLCBNYWluLCBOZXh0U2NyaXB0IH0gZnJvbSBcIm5leHQvZG9jdW1lbnRcIjtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gRG9jdW1lbnQoKSB7XG4gIHJldHVybiAoXG4gICAgPEh0bWwgbGFuZz1cImVuXCI+XG4gICAgICA8SGVhZCAvPlxuICAgICAgPGJvZHk+XG4gICAgICAgIDxNYWluIC8+XG4gICAgICAgIDxOZXh0U2NyaXB0IC8+XG4gICAgICA8L2JvZHk+XG4gICAgPC9IdG1sPlxuICApO1xufVxuIl0sIm5hbWVzIjpbIkh0bWwiLCJIZWFkIiwiTWFpbiIsIk5leHRTY3JpcHQiLCJEb2N1bWVudCIsImxhbmciLCJib2R5Il0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(pages-dir-node)/./pages/_document.js\n");

/***/ }),

/***/ "(pages-dir-node)/./pages/search.js":
/*!*************************!*\
  !*** ./pages/search.js ***!
  \*************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ AdvancedSearch)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/router */ \"(pages-dir-node)/./node_modules/next/router.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-hook-form */ \"react-hook-form\");\n/* harmony import */ var _barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! __barrel_optimize__?names=Button,Col,Form,Row!=!react-bootstrap */ \"(pages-dir-node)/__barrel_optimize__?names=Button,Col,Form,Row!=!./node_modules/react-bootstrap/esm/index.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_2__]);\nreact_hook_form__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n\nfunction AdvancedSearch() {\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();\n    const { register, handleSubmit, reset, formState: { errors } } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useForm)({\n        defaultValues: {\n            searchBy: 'title',\n            isHighlight: false,\n            isOnView: false\n        }\n    });\n    const onSubmit = (formData)=>{\n        let query = `${formData.searchBy}=true`;\n        if (formData.geoLocation) query += `&geoLocation=${encodeURIComponent(formData.geoLocation)}`;\n        if (formData.medium) query += `&medium=${encodeURIComponent(formData.medium)}`;\n        query += `&isOnView=${formData.isOnView}`;\n        query += `&isHighlight=${formData.isHighlight}`;\n        query += `&q=${encodeURIComponent(formData.q)}`;\n        router.push(`/artwork?${query}`);\n        reset();\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form, {\n        onSubmit: handleSubmit(onSubmit),\n        className: \"p-4 bg-dark text-white rounded\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Row, {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Col, {\n                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Group, {\n                        className: \"mb-3\",\n                        children: [\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Label, {\n                                children: \"Search Query\"\n                            }, void 0, false, {\n                                fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                                lineNumber: 42,\n                                columnNumber: 13\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Control, {\n                                type: \"text\",\n                                className: `bg-secondary text-white ${errors.q ? 'is-invalid' : ''}`,\n                                ...register('q', {\n                                    required: true\n                                })\n                            }, void 0, false, {\n                                fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                                lineNumber: 43,\n                                columnNumber: 13\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Control.Feedback, {\n                                type: \"invalid\",\n                                children: \"This field is required.\"\n                            }, void 0, false, {\n                                fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                                lineNumber: 48,\n                                columnNumber: 13\n                            }, this)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                        lineNumber: 41,\n                        columnNumber: 11\n                    }, this)\n                }, void 0, false, {\n                    fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                    lineNumber: 40,\n                    columnNumber: 9\n                }, this)\n            }, void 0, false, {\n                fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                lineNumber: 39,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Row, {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Col, {\n                        md: 4,\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Group, {\n                            className: \"mb-3\",\n                            children: [\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Label, {\n                                    children: \"Search By\"\n                                }, void 0, false, {\n                                    fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                                    lineNumber: 58,\n                                    columnNumber: 13\n                                }, this),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Select, {\n                                    ...register('searchBy'),\n                                    className: \"bg-secondary text-white\",\n                                    children: [\n                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"option\", {\n                                            value: \"title\",\n                                            children: \"Title\"\n                                        }, void 0, false, {\n                                            fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                                            lineNumber: 63,\n                                            columnNumber: 15\n                                        }, this),\n                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"option\", {\n                                            value: \"tags\",\n                                            children: \"Tags\"\n                                        }, void 0, false, {\n                                            fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                                            lineNumber: 64,\n                                            columnNumber: 15\n                                        }, this),\n                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"option\", {\n                                            value: \"artistOrCulture\",\n                                            children: \"Artist or Culture\"\n                                        }, void 0, false, {\n                                            fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                                            lineNumber: 65,\n                                            columnNumber: 15\n                                        }, this)\n                                    ]\n                                }, void 0, true, {\n                                    fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                                    lineNumber: 59,\n                                    columnNumber: 13\n                                }, this)\n                            ]\n                        }, void 0, true, {\n                            fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                            lineNumber: 57,\n                            columnNumber: 11\n                        }, this)\n                    }, void 0, false, {\n                        fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                        lineNumber: 56,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Col, {\n                        md: 4,\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Group, {\n                            className: \"mb-3\",\n                            children: [\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Label, {\n                                    children: \"Geo Location\"\n                                }, void 0, false, {\n                                    fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                                    lineNumber: 72,\n                                    columnNumber: 13\n                                }, this),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Control, {\n                                    type: \"text\",\n                                    className: \"bg-secondary text-white\",\n                                    ...register('geoLocation')\n                                }, void 0, false, {\n                                    fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                                    lineNumber: 73,\n                                    columnNumber: 13\n                                }, this),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Text, {\n                                    className: \"text-light\",\n                                    children: \"Case-sensitive (e.g. “Europe”), multiple values separated by “|”\"\n                                }, void 0, false, {\n                                    fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                                    lineNumber: 78,\n                                    columnNumber: 13\n                                }, this)\n                            ]\n                        }, void 0, true, {\n                            fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                            lineNumber: 71,\n                            columnNumber: 11\n                        }, this)\n                    }, void 0, false, {\n                        fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                        lineNumber: 70,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Col, {\n                        md: 4,\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Group, {\n                            className: \"mb-3\",\n                            children: [\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Label, {\n                                    children: \"Medium\"\n                                }, void 0, false, {\n                                    fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                                    lineNumber: 86,\n                                    columnNumber: 13\n                                }, this),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Control, {\n                                    type: \"text\",\n                                    className: \"bg-secondary text-white\",\n                                    ...register('medium')\n                                }, void 0, false, {\n                                    fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                                    lineNumber: 87,\n                                    columnNumber: 13\n                                }, this),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Text, {\n                                    className: \"text-light\",\n                                    children: \"Case-sensitive (e.g. “Paintings”), multiple values separated by “|”\"\n                                }, void 0, false, {\n                                    fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                                    lineNumber: 92,\n                                    columnNumber: 13\n                                }, this)\n                            ]\n                        }, void 0, true, {\n                            fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                            lineNumber: 85,\n                            columnNumber: 11\n                        }, this)\n                    }, void 0, false, {\n                        fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                        lineNumber: 84,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                lineNumber: 55,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Row, {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Col, {\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Check, {\n                            type: \"checkbox\",\n                            label: \"Highlighted\",\n                            ...register('isHighlight'),\n                            className: \"text-white\"\n                        }, void 0, false, {\n                            fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                            lineNumber: 101,\n                            columnNumber: 11\n                        }, this),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Check, {\n                            type: \"checkbox\",\n                            label: \"Currently on View\",\n                            ...register('isOnView'),\n                            className: \"text-white\"\n                        }, void 0, false, {\n                            fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                            lineNumber: 107,\n                            columnNumber: 11\n                        }, this)\n                    ]\n                }, void 0, true, {\n                    fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                    lineNumber: 100,\n                    columnNumber: 9\n                }, this)\n            }, void 0, false, {\n                fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                lineNumber: 99,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Row, {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Col, {\n                    className: \"mt-3\",\n                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Button, {\n                        variant: \"primary\",\n                        type: \"submit\",\n                        children: \"Search\"\n                    }, void 0, false, {\n                        fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                        lineNumber: 118,\n                        columnNumber: 11\n                    }, this)\n                }, void 0, false, {\n                    fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                    lineNumber: 117,\n                    columnNumber: 9\n                }, this)\n            }, void 0, false, {\n                fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n                lineNumber: 116,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"D:\\\\JOANNE\\\\SENECA\\\\SU25\\\\WEB422\\\\A5\\\\my-app\\\\pages\\\\search.js\",\n        lineNumber: 38,\n        columnNumber: 5\n    }, this);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHBhZ2VzLWRpci1ub2RlKS8uL3BhZ2VzL3NlYXJjaC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztBQUF3QztBQUNFO0FBQ2U7QUFFMUMsU0FBU007SUFDdEIsTUFBTUMsU0FBU1Asc0RBQVNBO0lBRXhCLE1BQU0sRUFDSlEsUUFBUSxFQUNSQyxZQUFZLEVBQ1pDLEtBQUssRUFDTEMsV0FBVyxFQUFFQyxNQUFNLEVBQUUsRUFDdEIsR0FBR1gsd0RBQU9BLENBQUM7UUFDVlksZUFBZTtZQUNiQyxVQUFVO1lBQ1ZDLGFBQWE7WUFDYkMsVUFBVTtRQUNaO0lBQ0Y7SUFFQSxNQUFNQyxXQUFXLENBQUNDO1FBQ2hCLElBQUlDLFFBQVEsR0FBR0QsU0FBU0osUUFBUSxDQUFDLEtBQUssQ0FBQztRQUV2QyxJQUFJSSxTQUFTRSxXQUFXLEVBQ3RCRCxTQUFTLENBQUMsYUFBYSxFQUFFRSxtQkFBbUJILFNBQVNFLFdBQVcsR0FBRztRQUNyRSxJQUFJRixTQUFTSSxNQUFNLEVBQ2pCSCxTQUFTLENBQUMsUUFBUSxFQUFFRSxtQkFBbUJILFNBQVNJLE1BQU0sR0FBRztRQUUzREgsU0FBUyxDQUFDLFVBQVUsRUFBRUQsU0FBU0YsUUFBUSxFQUFFO1FBQ3pDRyxTQUFTLENBQUMsYUFBYSxFQUFFRCxTQUFTSCxXQUFXLEVBQUU7UUFDL0NJLFNBQVMsQ0FBQyxHQUFHLEVBQUVFLG1CQUFtQkgsU0FBU0ssQ0FBQyxHQUFHO1FBRS9DaEIsT0FBT2lCLElBQUksQ0FBQyxDQUFDLFNBQVMsRUFBRUwsT0FBTztRQUMvQlQ7SUFDRjtJQUVBLHFCQUNFLDhEQUFDTiw0RkFBSUE7UUFBQ2EsVUFBVVIsYUFBYVE7UUFBV1EsV0FBVTs7MEJBQ2hELDhEQUFDdkIsMkZBQUdBOzBCQUNGLDRFQUFDQywyRkFBR0E7OEJBQ0YsNEVBQUNDLDRGQUFJQSxDQUFDc0IsS0FBSzt3QkFBQ0QsV0FBVTs7MENBQ3BCLDhEQUFDckIsNEZBQUlBLENBQUN1QixLQUFLOzBDQUFDOzs7Ozs7MENBQ1osOERBQUN2Qiw0RkFBSUEsQ0FBQ3dCLE9BQU87Z0NBQ1hDLE1BQUs7Z0NBQ0xKLFdBQVcsQ0FBQyx3QkFBd0IsRUFBRWIsT0FBT1csQ0FBQyxHQUFHLGVBQWUsSUFBSTtnQ0FDbkUsR0FBR2YsU0FBUyxLQUFLO29DQUFFc0IsVUFBVTtnQ0FBSyxFQUFFOzs7Ozs7MENBRXZDLDhEQUFDMUIsNEZBQUlBLENBQUN3QixPQUFPLENBQUNHLFFBQVE7Z0NBQUNGLE1BQUs7MENBQVU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7MEJBTzVDLDhEQUFDM0IsMkZBQUdBOztrQ0FDRiw4REFBQ0MsMkZBQUdBO3dCQUFDNkIsSUFBSTtrQ0FDUCw0RUFBQzVCLDRGQUFJQSxDQUFDc0IsS0FBSzs0QkFBQ0QsV0FBVTs7OENBQ3BCLDhEQUFDckIsNEZBQUlBLENBQUN1QixLQUFLOzhDQUFDOzs7Ozs7OENBQ1osOERBQUN2Qiw0RkFBSUEsQ0FBQzZCLE1BQU07b0NBQ1QsR0FBR3pCLFNBQVMsV0FBVztvQ0FDeEJpQixXQUFVOztzREFFViw4REFBQ1M7NENBQU9DLE9BQU07c0RBQVE7Ozs7OztzREFDdEIsOERBQUNEOzRDQUFPQyxPQUFNO3NEQUFPOzs7Ozs7c0RBQ3JCLDhEQUFDRDs0Q0FBT0MsT0FBTTtzREFBa0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2tDQUt0Qyw4REFBQ2hDLDJGQUFHQTt3QkFBQzZCLElBQUk7a0NBQ1AsNEVBQUM1Qiw0RkFBSUEsQ0FBQ3NCLEtBQUs7NEJBQUNELFdBQVU7OzhDQUNwQiw4REFBQ3JCLDRGQUFJQSxDQUFDdUIsS0FBSzs4Q0FBQzs7Ozs7OzhDQUNaLDhEQUFDdkIsNEZBQUlBLENBQUN3QixPQUFPO29DQUNYQyxNQUFLO29DQUNMSixXQUFVO29DQUNULEdBQUdqQixTQUFTLGNBQWM7Ozs7Ozs4Q0FFN0IsOERBQUNKLDRGQUFJQSxDQUFDZ0MsSUFBSTtvQ0FBQ1gsV0FBVTs4Q0FBYTs7Ozs7Ozs7Ozs7Ozs7Ozs7a0NBTXRDLDhEQUFDdEIsMkZBQUdBO3dCQUFDNkIsSUFBSTtrQ0FDUCw0RUFBQzVCLDRGQUFJQSxDQUFDc0IsS0FBSzs0QkFBQ0QsV0FBVTs7OENBQ3BCLDhEQUFDckIsNEZBQUlBLENBQUN1QixLQUFLOzhDQUFDOzs7Ozs7OENBQ1osOERBQUN2Qiw0RkFBSUEsQ0FBQ3dCLE9BQU87b0NBQ1hDLE1BQUs7b0NBQ0xKLFdBQVU7b0NBQ1QsR0FBR2pCLFNBQVMsU0FBUzs7Ozs7OzhDQUV4Qiw4REFBQ0osNEZBQUlBLENBQUNnQyxJQUFJO29DQUFDWCxXQUFVOzhDQUFhOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzswQkFPeEMsOERBQUN2QiwyRkFBR0E7MEJBQ0YsNEVBQUNDLDJGQUFHQTs7c0NBQ0YsOERBQUNDLDRGQUFJQSxDQUFDaUMsS0FBSzs0QkFDVFIsTUFBSzs0QkFDTFMsT0FBTTs0QkFDTCxHQUFHOUIsU0FBUyxjQUFjOzRCQUMzQmlCLFdBQVU7Ozs7OztzQ0FFWiw4REFBQ3JCLDRGQUFJQSxDQUFDaUMsS0FBSzs0QkFDVFIsTUFBSzs0QkFDTFMsT0FBTTs0QkFDTCxHQUFHOUIsU0FBUyxXQUFXOzRCQUN4QmlCLFdBQVU7Ozs7Ozs7Ozs7Ozs7Ozs7OzBCQUtoQiw4REFBQ3ZCLDJGQUFHQTswQkFDRiw0RUFBQ0MsMkZBQUdBO29CQUFDc0IsV0FBVTs4QkFDYiw0RUFBQ3BCLDhGQUFNQTt3QkFBQ2tDLFNBQVE7d0JBQVVWLE1BQUs7a0NBQVM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFPbEQiLCJzb3VyY2VzIjpbIkQ6XFxKT0FOTkVcXFNFTkVDQVxcU1UyNVxcV0VCNDIyXFxBNVxcbXktYXBwXFxwYWdlc1xcc2VhcmNoLmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ25leHQvcm91dGVyJztcclxuaW1wb3J0IHsgdXNlRm9ybSB9IGZyb20gJ3JlYWN0LWhvb2stZm9ybSc7XHJcbmltcG9ydCB7IFJvdywgQ29sLCBGb3JtLCBCdXR0b24gfSBmcm9tICdyZWFjdC1ib290c3RyYXAnO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQWR2YW5jZWRTZWFyY2goKSB7XHJcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcblxyXG4gIGNvbnN0IHtcclxuICAgIHJlZ2lzdGVyLFxyXG4gICAgaGFuZGxlU3VibWl0LFxyXG4gICAgcmVzZXQsXHJcbiAgICBmb3JtU3RhdGU6IHsgZXJyb3JzIH0sXHJcbiAgfSA9IHVzZUZvcm0oe1xyXG4gICAgZGVmYXVsdFZhbHVlczoge1xyXG4gICAgICBzZWFyY2hCeTogJ3RpdGxlJyxcclxuICAgICAgaXNIaWdobGlnaHQ6IGZhbHNlLFxyXG4gICAgICBpc09uVmlldzogZmFsc2UsXHJcbiAgICB9LFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBvblN1Ym1pdCA9IChmb3JtRGF0YSkgPT4ge1xyXG4gICAgbGV0IHF1ZXJ5ID0gYCR7Zm9ybURhdGEuc2VhcmNoQnl9PXRydWVgO1xyXG5cclxuICAgIGlmIChmb3JtRGF0YS5nZW9Mb2NhdGlvbilcclxuICAgICAgcXVlcnkgKz0gYCZnZW9Mb2NhdGlvbj0ke2VuY29kZVVSSUNvbXBvbmVudChmb3JtRGF0YS5nZW9Mb2NhdGlvbil9YDtcclxuICAgIGlmIChmb3JtRGF0YS5tZWRpdW0pXHJcbiAgICAgIHF1ZXJ5ICs9IGAmbWVkaXVtPSR7ZW5jb2RlVVJJQ29tcG9uZW50KGZvcm1EYXRhLm1lZGl1bSl9YDtcclxuXHJcbiAgICBxdWVyeSArPSBgJmlzT25WaWV3PSR7Zm9ybURhdGEuaXNPblZpZXd9YDtcclxuICAgIHF1ZXJ5ICs9IGAmaXNIaWdobGlnaHQ9JHtmb3JtRGF0YS5pc0hpZ2hsaWdodH1gO1xyXG4gICAgcXVlcnkgKz0gYCZxPSR7ZW5jb2RlVVJJQ29tcG9uZW50KGZvcm1EYXRhLnEpfWA7XHJcblxyXG4gICAgcm91dGVyLnB1c2goYC9hcnR3b3JrPyR7cXVlcnl9YCk7XHJcbiAgICByZXNldCgpO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8Rm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0KG9uU3VibWl0KX0gY2xhc3NOYW1lPVwicC00IGJnLWRhcmsgdGV4dC13aGl0ZSByb3VuZGVkXCI+XHJcbiAgICAgIDxSb3c+XHJcbiAgICAgICAgPENvbD5cclxuICAgICAgICAgIDxGb3JtLkdyb3VwIGNsYXNzTmFtZT1cIm1iLTNcIj5cclxuICAgICAgICAgICAgPEZvcm0uTGFiZWw+U2VhcmNoIFF1ZXJ5PC9Gb3JtLkxhYmVsPlxyXG4gICAgICAgICAgICA8Rm9ybS5Db250cm9sXHJcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLXNlY29uZGFyeSB0ZXh0LXdoaXRlICR7ZXJyb3JzLnEgPyAnaXMtaW52YWxpZCcgOiAnJ31gfVxyXG4gICAgICAgICAgICAgIHsuLi5yZWdpc3RlcigncScsIHsgcmVxdWlyZWQ6IHRydWUgfSl9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxGb3JtLkNvbnRyb2wuRmVlZGJhY2sgdHlwZT1cImludmFsaWRcIj5cclxuICAgICAgICAgICAgICBUaGlzIGZpZWxkIGlzIHJlcXVpcmVkLlxyXG4gICAgICAgICAgICA8L0Zvcm0uQ29udHJvbC5GZWVkYmFjaz5cclxuICAgICAgICAgIDwvRm9ybS5Hcm91cD5cclxuICAgICAgICA8L0NvbD5cclxuICAgICAgPC9Sb3c+XHJcblxyXG4gICAgICA8Um93PlxyXG4gICAgICAgIDxDb2wgbWQ9ezR9PlxyXG4gICAgICAgICAgPEZvcm0uR3JvdXAgY2xhc3NOYW1lPVwibWItM1wiPlxyXG4gICAgICAgICAgICA8Rm9ybS5MYWJlbD5TZWFyY2ggQnk8L0Zvcm0uTGFiZWw+XHJcbiAgICAgICAgICAgIDxGb3JtLlNlbGVjdFxyXG4gICAgICAgICAgICAgIHsuLi5yZWdpc3Rlcignc2VhcmNoQnknKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zZWNvbmRhcnkgdGV4dC13aGl0ZVwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwidGl0bGVcIj5UaXRsZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJ0YWdzXCI+VGFnczwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJhcnRpc3RPckN1bHR1cmVcIj5BcnRpc3Qgb3IgQ3VsdHVyZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICA8L0Zvcm0uU2VsZWN0PlxyXG4gICAgICAgICAgPC9Gb3JtLkdyb3VwPlxyXG4gICAgICAgIDwvQ29sPlxyXG5cclxuICAgICAgICA8Q29sIG1kPXs0fT5cclxuICAgICAgICAgIDxGb3JtLkdyb3VwIGNsYXNzTmFtZT1cIm1iLTNcIj5cclxuICAgICAgICAgICAgPEZvcm0uTGFiZWw+R2VvIExvY2F0aW9uPC9Gb3JtLkxhYmVsPlxyXG4gICAgICAgICAgICA8Rm9ybS5Db250cm9sXHJcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNlY29uZGFyeSB0ZXh0LXdoaXRlXCJcclxuICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoJ2dlb0xvY2F0aW9uJyl9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxGb3JtLlRleHQgY2xhc3NOYW1lPVwidGV4dC1saWdodFwiPlxyXG4gICAgICAgICAgICAgIENhc2Utc2Vuc2l0aXZlIChlLmcuIOKAnEV1cm9wZeKAnSksIG11bHRpcGxlIHZhbHVlcyBzZXBhcmF0ZWQgYnkg4oCcfOKAnVxyXG4gICAgICAgICAgICA8L0Zvcm0uVGV4dD5cclxuICAgICAgICAgIDwvRm9ybS5Hcm91cD5cclxuICAgICAgICA8L0NvbD5cclxuXHJcbiAgICAgICAgPENvbCBtZD17NH0+XHJcbiAgICAgICAgICA8Rm9ybS5Hcm91cCBjbGFzc05hbWU9XCJtYi0zXCI+XHJcbiAgICAgICAgICAgIDxGb3JtLkxhYmVsPk1lZGl1bTwvRm9ybS5MYWJlbD5cclxuICAgICAgICAgICAgPEZvcm0uQ29udHJvbFxyXG4gICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zZWNvbmRhcnkgdGV4dC13aGl0ZVwiXHJcbiAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKCdtZWRpdW0nKX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPEZvcm0uVGV4dCBjbGFzc05hbWU9XCJ0ZXh0LWxpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgQ2FzZS1zZW5zaXRpdmUgKGUuZy4g4oCcUGFpbnRpbmdz4oCdKSwgbXVsdGlwbGUgdmFsdWVzIHNlcGFyYXRlZCBieSDigJx84oCdXHJcbiAgICAgICAgICAgIDwvRm9ybS5UZXh0PlxyXG4gICAgICAgICAgPC9Gb3JtLkdyb3VwPlxyXG4gICAgICAgIDwvQ29sPlxyXG4gICAgICA8L1Jvdz5cclxuXHJcbiAgICAgIDxSb3c+XHJcbiAgICAgICAgPENvbD5cclxuICAgICAgICAgIDxGb3JtLkNoZWNrXHJcbiAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgIGxhYmVsPVwiSGlnaGxpZ2h0ZWRcIlxyXG4gICAgICAgICAgICB7Li4ucmVnaXN0ZXIoJ2lzSGlnaGxpZ2h0Jyl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtd2hpdGVcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxGb3JtLkNoZWNrXHJcbiAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgIGxhYmVsPVwiQ3VycmVudGx5IG9uIFZpZXdcIlxyXG4gICAgICAgICAgICB7Li4ucmVnaXN0ZXIoJ2lzT25WaWV3Jyl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtd2hpdGVcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L0NvbD5cclxuICAgICAgPC9Sb3c+XHJcblxyXG4gICAgICA8Um93PlxyXG4gICAgICAgIDxDb2wgY2xhc3NOYW1lPVwibXQtM1wiPlxyXG4gICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwicHJpbWFyeVwiIHR5cGU9XCJzdWJtaXRcIj5cclxuICAgICAgICAgICAgU2VhcmNoXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICA8L0NvbD5cclxuICAgICAgPC9Sb3c+XHJcbiAgICA8L0Zvcm0+XHJcbiAgKTtcclxufVxyXG4iXSwibmFtZXMiOlsidXNlUm91dGVyIiwidXNlRm9ybSIsIlJvdyIsIkNvbCIsIkZvcm0iLCJCdXR0b24iLCJBZHZhbmNlZFNlYXJjaCIsInJvdXRlciIsInJlZ2lzdGVyIiwiaGFuZGxlU3VibWl0IiwicmVzZXQiLCJmb3JtU3RhdGUiLCJlcnJvcnMiLCJkZWZhdWx0VmFsdWVzIiwic2VhcmNoQnkiLCJpc0hpZ2hsaWdodCIsImlzT25WaWV3Iiwib25TdWJtaXQiLCJmb3JtRGF0YSIsInF1ZXJ5IiwiZ2VvTG9jYXRpb24iLCJlbmNvZGVVUklDb21wb25lbnQiLCJtZWRpdW0iLCJxIiwicHVzaCIsImNsYXNzTmFtZSIsIkdyb3VwIiwiTGFiZWwiLCJDb250cm9sIiwidHlwZSIsInJlcXVpcmVkIiwiRmVlZGJhY2siLCJtZCIsIlNlbGVjdCIsIm9wdGlvbiIsInZhbHVlIiwiVGV4dCIsIkNoZWNrIiwibGFiZWwiLCJ2YXJpYW50Il0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(pages-dir-node)/./pages/search.js\n");

/***/ }),

/***/ "(pages-dir-node)/./store.js":
/*!******************!*\
  !*** ./store.js ***!
  \******************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   favouritesAtom: () => (/* binding */ favouritesAtom),\n/* harmony export */   searchHistoryAtom: () => (/* binding */ searchHistoryAtom)\n/* harmony export */ });\n/* harmony import */ var jotai__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jotai */ \"jotai\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([jotai__WEBPACK_IMPORTED_MODULE_0__]);\njotai__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\nconst searchHistoryAtom = (0,jotai__WEBPACK_IMPORTED_MODULE_0__.atom)([]);\nconst favouritesAtom = (0,jotai__WEBPACK_IMPORTED_MODULE_0__.atom)([]);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHBhZ2VzLWRpci1ub2RlKS8uL3N0b3JlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUE2QjtBQUV0QixNQUFNQyxvQkFBb0JELDJDQUFJQSxDQUFDLEVBQUUsRUFBRTtBQUNuQyxNQUFNRSxpQkFBaUJGLDJDQUFJQSxDQUFDLEVBQUUsRUFBRSIsInNvdXJjZXMiOlsiRDpcXEpPQU5ORVxcU0VORUNBXFxTVTI1XFxXRUI0MjJcXEE1XFxteS1hcHBcXHN0b3JlLmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGF0b20gfSBmcm9tIFwiam90YWlcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBzZWFyY2hIaXN0b3J5QXRvbSA9IGF0b20oW10pO1xyXG5leHBvcnQgY29uc3QgZmF2b3VyaXRlc0F0b20gPSBhdG9tKFtdKTsiXSwibmFtZXMiOlsiYXRvbSIsInNlYXJjaEhpc3RvcnlBdG9tIiwiZmF2b3VyaXRlc0F0b20iXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(pages-dir-node)/./store.js\n");

/***/ }),

/***/ "(pages-dir-node)/./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "(pages-dir-node)/__barrel_optimize__?names=Button,Col,Form,Row!=!./node_modules/react-bootstrap/esm/index.js":
/*!***************************************************************************************************!*\
  !*** __barrel_optimize__?names=Button,Col,Form,Row!=!./node_modules/react-bootstrap/esm/index.js ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Button: () => (/* reexport safe */ _Button__WEBPACK_IMPORTED_MODULE_0__[\"default\"]),\n/* harmony export */   Col: () => (/* reexport safe */ _Col__WEBPACK_IMPORTED_MODULE_1__[\"default\"]),\n/* harmony export */   Form: () => (/* reexport safe */ _Form__WEBPACK_IMPORTED_MODULE_2__[\"default\"]),\n/* harmony export */   Row: () => (/* reexport safe */ _Row__WEBPACK_IMPORTED_MODULE_3__[\"default\"])\n/* harmony export */ });\n/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Button */ \"(pages-dir-node)/./node_modules/react-bootstrap/esm/Button.js\");\n/* harmony import */ var _Col__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Col */ \"(pages-dir-node)/./node_modules/react-bootstrap/esm/Col.js\");\n/* harmony import */ var _Form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Form */ \"(pages-dir-node)/./node_modules/react-bootstrap/esm/Form.js\");\n/* harmony import */ var _Row__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Row */ \"(pages-dir-node)/./node_modules/react-bootstrap/esm/Row.js\");\n\n\n\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHBhZ2VzLWRpci1ub2RlKS9fX2JhcnJlbF9vcHRpbWl6ZV9fP25hbWVzPUJ1dHRvbixDb2wsRm9ybSxSb3chPSEuL25vZGVfbW9kdWxlcy9yZWFjdC1ib290c3RyYXAvZXNtL2luZGV4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQUM0QztBQUNOO0FBQ0UiLCJzb3VyY2VzIjpbIkQ6XFxKT0FOTkVcXFNFTkVDQVxcU1UyNVxcV0VCNDIyXFxBNVxcbXktYXBwXFxub2RlX21vZHVsZXNcXHJlYWN0LWJvb3RzdHJhcFxcZXNtXFxpbmRleC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgQnV0dG9uIH0gZnJvbSBcIi4vQnV0dG9uXCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgQ29sIH0gZnJvbSBcIi4vQ29sXCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgRm9ybSB9IGZyb20gXCIuL0Zvcm1cIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBSb3cgfSBmcm9tIFwiLi9Sb3dcIiJdLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOlswXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(pages-dir-node)/__barrel_optimize__?names=Button,Col,Form,Row!=!./node_modules/react-bootstrap/esm/index.js\n");

/***/ }),

/***/ "(pages-dir-node)/__barrel_optimize__?names=Button,Container,Form,Nav,NavDropdown,Navbar!=!./node_modules/react-bootstrap/esm/index.js":
/*!****************************************************************************************************************************!*\
  !*** __barrel_optimize__?names=Button,Container,Form,Nav,NavDropdown,Navbar!=!./node_modules/react-bootstrap/esm/index.js ***!
  \****************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Button: () => (/* reexport safe */ _Button__WEBPACK_IMPORTED_MODULE_0__[\"default\"]),\n/* harmony export */   Container: () => (/* reexport safe */ _Container__WEBPACK_IMPORTED_MODULE_1__[\"default\"]),\n/* harmony export */   Form: () => (/* reexport safe */ _Form__WEBPACK_IMPORTED_MODULE_2__[\"default\"]),\n/* harmony export */   Nav: () => (/* reexport safe */ _Nav__WEBPACK_IMPORTED_MODULE_3__[\"default\"]),\n/* harmony export */   NavDropdown: () => (/* reexport safe */ _NavDropdown__WEBPACK_IMPORTED_MODULE_4__[\"default\"]),\n/* harmony export */   Navbar: () => (/* reexport safe */ _Navbar__WEBPACK_IMPORTED_MODULE_5__[\"default\"])\n/* harmony export */ });\n/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Button */ \"(pages-dir-node)/./node_modules/react-bootstrap/esm/Button.js\");\n/* harmony import */ var _Container__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Container */ \"(pages-dir-node)/./node_modules/react-bootstrap/esm/Container.js\");\n/* harmony import */ var _Form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Form */ \"(pages-dir-node)/./node_modules/react-bootstrap/esm/Form.js\");\n/* harmony import */ var _Nav__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Nav */ \"(pages-dir-node)/./node_modules/react-bootstrap/esm/Nav.js\");\n/* harmony import */ var _NavDropdown__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./NavDropdown */ \"(pages-dir-node)/./node_modules/react-bootstrap/esm/NavDropdown.js\");\n/* harmony import */ var _Navbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Navbar */ \"(pages-dir-node)/./node_modules/react-bootstrap/esm/Navbar.js\");\n\n\n\n\n\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHBhZ2VzLWRpci1ub2RlKS9fX2JhcnJlbF9vcHRpbWl6ZV9fP25hbWVzPUJ1dHRvbixDb250YWluZXIsRm9ybSxOYXYsTmF2RHJvcGRvd24sTmF2YmFyIT0hLi9ub2RlX21vZHVsZXMvcmVhY3QtYm9vdHN0cmFwL2VzbS9pbmRleC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQzRDO0FBQ007QUFDVjtBQUNGO0FBQ2dCIiwic291cmNlcyI6WyJEOlxcSk9BTk5FXFxTRU5FQ0FcXFNVMjVcXFdFQjQyMlxcQTVcXG15LWFwcFxcbm9kZV9tb2R1bGVzXFxyZWFjdC1ib290c3RyYXBcXGVzbVxcaW5kZXguanMiXSwic291cmNlc0NvbnRlbnQiOlsiXG5leHBvcnQgeyBkZWZhdWx0IGFzIEJ1dHRvbiB9IGZyb20gXCIuL0J1dHRvblwiXG5leHBvcnQgeyBkZWZhdWx0IGFzIENvbnRhaW5lciB9IGZyb20gXCIuL0NvbnRhaW5lclwiXG5leHBvcnQgeyBkZWZhdWx0IGFzIEZvcm0gfSBmcm9tIFwiLi9Gb3JtXCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgTmF2IH0gZnJvbSBcIi4vTmF2XCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgTmF2RHJvcGRvd24gfSBmcm9tIFwiLi9OYXZEcm9wZG93blwiXG5leHBvcnQgeyBkZWZhdWx0IGFzIE5hdmJhciB9IGZyb20gXCIuL05hdmJhclwiIl0sIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6WzBdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(pages-dir-node)/__barrel_optimize__?names=Button,Container,Form,Nav,NavDropdown,Navbar!=!./node_modules/react-bootstrap/esm/index.js\n");

/***/ }),

/***/ "(pages-dir-node)/__barrel_optimize__?names=Container!=!./node_modules/react-bootstrap/esm/index.js":
/*!*****************************************************************************************!*\
  !*** __barrel_optimize__?names=Container!=!./node_modules/react-bootstrap/esm/index.js ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Container: () => (/* reexport safe */ _Container__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var _Container__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Container */ "(pages-dir-node)/./node_modules/react-bootstrap/esm/Container.js");



/***/ }),

/***/ "@restart/hooks/useBreakpoint":
/*!***********************************************!*\
  !*** external "@restart/hooks/useBreakpoint" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useBreakpoint");

/***/ }),

/***/ "@restart/hooks/useEventCallback":
/*!**************************************************!*\
  !*** external "@restart/hooks/useEventCallback" ***!
  \**************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useEventCallback");

/***/ }),

/***/ "@restart/hooks/useIsomorphicEffect":
/*!*****************************************************!*\
  !*** external "@restart/hooks/useIsomorphicEffect" ***!
  \*****************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useIsomorphicEffect");

/***/ }),

/***/ "@restart/hooks/useMergedRefs":
/*!***********************************************!*\
  !*** external "@restart/hooks/useMergedRefs" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useMergedRefs");

/***/ }),

/***/ "@restart/ui/Anchor":
/*!*************************************!*\
  !*** external "@restart/ui/Anchor" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Anchor");

/***/ }),

/***/ "@restart/ui/Button":
/*!*************************************!*\
  !*** external "@restart/ui/Button" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Button");

/***/ }),

/***/ "@restart/ui/Dropdown":
/*!***************************************!*\
  !*** external "@restart/ui/Dropdown" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Dropdown");

/***/ }),

/***/ "@restart/ui/DropdownContext":
/*!**********************************************!*\
  !*** external "@restart/ui/DropdownContext" ***!
  \**********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/DropdownContext");

/***/ }),

/***/ "@restart/ui/DropdownItem":
/*!*******************************************!*\
  !*** external "@restart/ui/DropdownItem" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/DropdownItem");

/***/ }),

/***/ "@restart/ui/DropdownMenu":
/*!*******************************************!*\
  !*** external "@restart/ui/DropdownMenu" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/DropdownMenu");

/***/ }),

/***/ "@restart/ui/DropdownToggle":
/*!*********************************************!*\
  !*** external "@restart/ui/DropdownToggle" ***!
  \*********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/DropdownToggle");

/***/ }),

/***/ "@restart/ui/Modal":
/*!************************************!*\
  !*** external "@restart/ui/Modal" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Modal");

/***/ }),

/***/ "@restart/ui/ModalManager":
/*!*******************************************!*\
  !*** external "@restart/ui/ModalManager" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/ModalManager");

/***/ }),

/***/ "@restart/ui/Nav":
/*!**********************************!*\
  !*** external "@restart/ui/Nav" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Nav");

/***/ }),

/***/ "@restart/ui/NavItem":
/*!**************************************!*\
  !*** external "@restart/ui/NavItem" ***!
  \**************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/NavItem");

/***/ }),

/***/ "@restart/ui/SelectableContext":
/*!************************************************!*\
  !*** external "@restart/ui/SelectableContext" ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/SelectableContext");

/***/ }),

/***/ "@restart/ui/utils":
/*!************************************!*\
  !*** external "@restart/ui/utils" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/utils");

/***/ }),

/***/ "classnames":
/*!*****************************!*\
  !*** external "classnames" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ "dom-helpers/addClass":
/*!***************************************!*\
  !*** external "dom-helpers/addClass" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/addClass");

/***/ }),

/***/ "dom-helpers/css":
/*!**********************************!*\
  !*** external "dom-helpers/css" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/css");

/***/ }),

/***/ "dom-helpers/querySelectorAll":
/*!***********************************************!*\
  !*** external "dom-helpers/querySelectorAll" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/querySelectorAll");

/***/ }),

/***/ "dom-helpers/removeClass":
/*!******************************************!*\
  !*** external "dom-helpers/removeClass" ***!
  \******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/removeClass");

/***/ }),

/***/ "dom-helpers/transitionEnd":
/*!********************************************!*\
  !*** external "dom-helpers/transitionEnd" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/transitionEnd");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ "invariant":
/*!****************************!*\
  !*** external "invariant" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("invariant");

/***/ }),

/***/ "jotai":
/*!************************!*\
  !*** external "jotai" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = import("jotai");;

/***/ }),

/***/ "next/dist/compiled/next-server/pages.runtime.dev.js":
/*!**********************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages.runtime.dev.js" ***!
  \**********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/pages.runtime.dev.js");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ "prop-types":
/*!*****************************!*\
  !*** external "prop-types" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("prop-types");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-dom":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ "react-hook-form":
/*!**********************************!*\
  !*** external "react-hook-form" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = import("react-hook-form");;

/***/ }),

/***/ "react-transition-group/Transition":
/*!****************************************************!*\
  !*** external "react-transition-group/Transition" ***!
  \****************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-transition-group/Transition");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "react/jsx-runtime":
/*!************************************!*\
  !*** external "react/jsx-runtime" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "swr":
/*!**********************!*\
  !*** external "swr" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = import("swr");;

/***/ }),

/***/ "uncontrollable":
/*!*********************************!*\
  !*** external "uncontrollable" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("uncontrollable");

/***/ }),

/***/ "warning":
/*!**************************!*\
  !*** external "warning" ***!
  \**************************/
/***/ ((module) => {

"use strict";
module.exports = require("warning");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@swc","vendor-chunks/react-bootstrap","vendor-chunks/bootstrap"], () => (__webpack_exec__("(pages-dir-node)/./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2Fsearch&preferredRegion=&absolutePagePath=.%2Fpages%5Csearch.js&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D!")));
module.exports = __webpack_exports__;

})();
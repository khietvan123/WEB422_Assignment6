import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { Navbar, Nav, Container, Form, Button, NavDropdown } from 'react-bootstrap';
import { useAtom } from 'jotai';
import { searchHistoryAtom } from '@/store';
import Link from 'next/link';

export default function MainNav() {
  const [searchField, setSearchField] = useState('');
  const [isExpanded, setIsExpanded] = useState(false);
  const [isClient, setIsClient] = useState(false);
  const router = useRouter();
  if(!router.isReady) return null; // Ensure router is ready before using it
  const [searchHistory, setSearchHistory] = useAtom(searchHistoryAtom);


  useEffect(() => {
    setIsClient(true);
  }, []);

  function submitHandler(e) {
    e.preventDefault();
    if (searchField.trim()) {
      const queryString = `title=true&q=${searchField}`;
      router.push(`/artwork?${queryString}`);
      setSearchHistory(current => [...current, queryString]);
      setSearchField('');
      setIsExpanded(false);
    }
  }

  if (!isClient || !router.isReady) return null;

  return (
    <Navbar expand="lg" className="fixed-top navbar-dark bg-dark" expanded={isExpanded}>
      <Container>
        <Navbar.Brand>Khiet Van Phan</Navbar.Brand>
        <Navbar.Toggle aria-controls="main-navbar-nav" onClick={() => setIsExpanded(!isExpanded)} />
        <Navbar.Collapse id="main-navbar-nav">
          <Nav className="me-auto">
            <Link href="/" passHref legacyBehavior>
              <Nav.Link
                active={router.pathname === '/'}
                onClick={() => setIsExpanded(false)}
                as="span"
              >
                Home
              </Nav.Link>
            </Link>
            <Link href="/search" passHref legacyBehavior>
              <Nav.Link
                active={router.isReady && router.pathname === '/search'}
                onClick={() => setIsExpanded(false)}
                as="span"
              >
                Advanced Search
              </Nav.Link>
            </Link>
          </Nav>
          &nbsp;
          <Form className="d-flex" onSubmit={submitHandler}>
            <Form.Control
              type="search"
              placeholder="Search"
              className="me-2"
              value={searchField}
              onChange={(e) => setSearchField(e.target.value)}
            />
            <Button type="submit" variant="outline-light">
              Search
            </Button>
          </Form>
          &nbsp;
          <Nav>
            <NavDropdown title="User Name" id="basic-nav-dropdown">
              <NavDropdown.Item
                as={Link}
                href="/favourites"
                active={router.isReady && router.pathname === '/favourites'}
                onClick={() => setIsExpanded(false)}
              >
                Favourites
              </NavDropdown.Item>

              <NavDropdown.Item
                as={Link}
                href="/history"
                active={router.isReady && router.pathname === '/history'}
                onClick={() => setIsExpanded(false)}
              >
                Search History
              </NavDropdown.Item>
            </NavDropdown>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

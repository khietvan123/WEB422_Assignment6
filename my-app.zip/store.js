import { atom } from "jotai";

export const searchHistoryAtom = atom([]);
export const favouritesAtom = atom([]);
import { useRouter } from 'next/router';
import { useForm } from 'react-hook-form';
import { Row, Col, Form, Button } from 'react-bootstrap';

export default function AdvancedSearch() {
  const router = useRouter();

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    defaultValues: {
      searchBy: 'title',
      isHighlight: false,
      isOnView: false,
    },
  });

  const onSubmit = (formData) => {
    let query = `${formData.searchBy}=true`;

    if (formData.geoLocation)
      query += `&geoLocation=${encodeURIComponent(formData.geoLocation)}`;
    if (formData.medium)
      query += `&medium=${encodeURIComponent(formData.medium)}`;

    query += `&isOnView=${formData.isOnView}`;
    query += `&isHighlight=${formData.isHighlight}`;
    query += `&q=${encodeURIComponent(formData.q)}`;

    router.push(`/artwork?${query}`);
    reset();
  };

  return (
    <Form onSubmit={handleSubmit(onSubmit)} className="p-4 bg-dark text-white rounded">
      <Row>
        <Col>
          <Form.Group className="mb-3">
            <Form.Label>Search Query</Form.Label>
            <Form.Control
              type="text"
              className={`bg-secondary text-white ${errors.q ? 'is-invalid' : ''}`}
              {...register('q', { required: true })}
            />
            <Form.Control.Feedback type="invalid">
              This field is required.
            </Form.Control.Feedback>
          </Form.Group>
        </Col>
      </Row>

      <Row>
        <Col md={4}>
          <Form.Group className="mb-3">
            <Form.Label>Search By</Form.Label>
            <Form.Select
              {...register('searchBy')}
              className="bg-secondary text-white"
            >
              <option value="title">Title</option>
              <option value="tags">Tags</option>
              <option value="artistOrCulture">Artist or Culture</option>
            </Form.Select>
          </Form.Group>
        </Col>

        <Col md={4}>
          <Form.Group className="mb-3">
            <Form.Label>Geo Location</Form.Label>
            <Form.Control
              type="text"
              className="bg-secondary text-white"
              {...register('geoLocation')}
            />
            <Form.Text className="text-light">
              Case-sensitive (e.g. “Europe”), multiple values separated by “|”
            </Form.Text>
          </Form.Group>
        </Col>

        <Col md={4}>
          <Form.Group className="mb-3">
            <Form.Label>Medium</Form.Label>
            <Form.Control
              type="text"
              className="bg-secondary text-white"
              {...register('medium')}
            />
            <Form.Text className="text-light">
              Case-sensitive (e.g. “Paintings”), multiple values separated by “|”
            </Form.Text>
          </Form.Group>
        </Col>
      </Row>

      <Row>
        <Col>
          <Form.Check
            type="checkbox"
            label="Highlighted"
            {...register('isHighlight')}
            className="text-white"
          />
          <Form.Check
            type="checkbox"
            label="Currently on View"
            {...register('isOnView')}
            className="text-white"
          />
        </Col>
      </Row>

      <Row>
        <Col className="mt-3">
          <Button variant="primary" type="submit">
            Search
          </Button>
        </Col>
      </Row>
    </Form>
  );
}
